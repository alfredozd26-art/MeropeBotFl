# Design Guidelines: Discord Gacha Bot Dashboard

## Design Approach
**Selected Approach:** Reference-Based (Gaming Dashboard)
**Primary References:** Discord's UI, Genshin Impact's gacha interface, MEE6 dashboard
**Design Philosophy:** Dark-themed gaming aesthetic with vibrant accents and playful interactions that match Discord's familiar environment while showcasing gacha excitement

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary):**
- Background Base: 220 13% 12% (Deep discord-like navy)
- Surface: 220 13% 18% (Elevated cards)
- Primary Brand: 235 86% 65% (Discord blurple)
- Accent Gacha: 280 80% 60% (Vibrant purple for gacha elements)
- Success/Rare: 142 76% 36% (Green for rare items)
- Epic/Special: 271 81% 56% (Purple for epic drops)
- Legendary: 45 93% 58% (Gold for legendary items)
- Text Primary: 0 0% 100%
- Text Secondary: 215 16% 65%

### B. Typography

**Font Stack:**
- Primary: 'Inter' or 'DM Sans' via Google Fonts (clean, modern readability)
- Display/Headers: 'Poppins' or 'Montserrat' SemiBold (gaming aesthetic)
- Code/Stats: 'JetBrains Mono' (for bot commands and IDs)

**Type Scale:**
- Hero/Display: text-5xl to text-6xl font-bold
- Section Headers: text-3xl font-semibold
- Card Titles: text-xl font-medium
- Body: text-base
- Stats/Labels: text-sm font-medium

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Tight spacing: p-2, gap-2 (for compact stats)
- Standard spacing: p-4, gap-4 (most components)
- Section spacing: p-8, py-12, py-20 (major sections)
- Generous spacing: p-16, py-24 (hero areas)

**Grid System:**
- Dashboard Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Stats Overview: grid-cols-2 md:grid-cols-4
- Gacha Results: grid-cols-2 md:grid-cols-3 lg:grid-cols-5
- Max Container: max-w-7xl mx-auto

### D. Component Library

**Navigation:**
- Sticky dark sidebar with Discord-style navigation icons
- Top bar with user profile, notifications, server selector
- Breadcrumbs for deep navigation (text-sm with chevrons)

**Dashboard Cards:**
- Rounded-xl borders with subtle border (border-white/10)
- Gradient overlays for premium/special items (from-purple-500/20 to-transparent)
- Hover states with scale-102 transition
- Icon badges for rarity levels (top-right corner)

**Gacha Display:**
- Large card reveal animation area (central focus)
- Rarity-based glow effects (box-shadow with color)
- Collection grid with filter/sort options
- Pull history timeline with visual rarity indicators

**Stats & Data:**
- Metric cards with large numbers (text-3xl) and trend indicators
- Progress bars for gacha pity system
- Circular progress for ticket counts
- Live activity feed (Discord message style)

**Forms & Controls:**
- Discord-style input fields (bg-black/30, rounded-lg)
- Role assignment dropdowns with color preview
- Toggle switches for bot features
- Command builder with syntax highlighting

**Overlays:**
- Modal for gacha pull results (full-screen dramatic reveal)
- Toast notifications (top-right, Discord-style)
- Confirmation dialogs (centered, frosted glass effect)

### E. Visual Enhancements

**Gacha Pull Mechanics:**
- Dramatic card flip animations for pulls
- Particle effects on rare drops (sparkles, glow)
- Color-coded rarity beams (shooting from card)
- Sound toggle for pull effects

**Status Indicators:**
- Pulsing dot for bot online status (green)
- Animated ticket counter with increment effects
- Real-time activity feed with smooth transitions
- Role badges with server icon integration

**Data Visualization:**
- Pull statistics charts (area charts for history)
- Rarity distribution pie charts
- Server engagement metrics (bar graphs)
- User inventory with filter chips

## Images

**Hero Section:**
- Large banner showcasing gacha characters/items in action (1200x400px)
- Animated gradient background with subtle particle effects
- Discord bot mascot or gacha banner art

**Dashboard:**
- Gacha item thumbnails (200x200px cards with rarity borders)
- Server icons and user avatars (circular, 48px)
- Achievement badges and role icons (24px-32px)
- Background patterns (subtle gaming-themed textures)

**Empty States:**
- Illustrated "No items yet" with friendly character
- "Start your first pull" call-to-action illustration

## Special Considerations

**Discord Integration:**
- Match Discord's familiar dark theme and interaction patterns
- Use Discord's role color system for consistency
- Embed-style cards for displaying bot responses
- Server sidebar mimicking Discord's server list

**Gaming Aesthetic:**
- Subtle scan-line overlays on premium sections
- Holographic effects on legendary items
- Energy/tech-inspired accent patterns
- Playful micro-interactions (bounces, wobbles)

**Responsiveness:**
- Mobile-first gacha pull interface (portrait optimized)
- Collapsible sidebar on mobile
- Touch-friendly card interactions
- Simplified stats view for small screens