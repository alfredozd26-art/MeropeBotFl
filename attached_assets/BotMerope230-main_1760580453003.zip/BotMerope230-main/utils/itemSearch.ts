
import * as storage from '../server/storage';

export async function searchItemByPartialName(guildId: string, partialName: string): Promise<any | null> {
  const allItems = await storage.getAllItems(guildId);
  const searchLower = partialName.toLowerCase().trim();
  
  // Exact match first
  const exactMatch = allItems.find(item => item.name.toLowerCase() === searchLower);
  if (exactMatch) return exactMatch;
  
  // Partial match
  const partialMatches = allItems.filter(item => 
    item.name.toLowerCase().includes(searchLower)
  );
  
  if (partialMatches.length === 1) {
    return partialMatches[0];
  }
  
  if (partialMatches.length > 1) {
    // Return the first match if multiple found
    return partialMatches[0];
  }
  
  return null;
}

export function searchItemByPartialNameSync(partialName: string, allItems: any[]): { type: 'none' | 'exact' | 'unique' | 'multiple'; item?: any; matches?: any[] } {
  const searchLower = partialName.toLowerCase().trim();
  
  // Exact match first
  const exactMatch = allItems.find(item => item.name.toLowerCase() === searchLower);
  if (exactMatch) return { type: 'exact', item: exactMatch };
  
  // Partial match
  const partialMatches = allItems.filter(item => 
    item.name.toLowerCase().includes(searchLower)
  );
  
  if (partialMatches.length === 0) {
    return { type: 'none' };
  }
  
  if (partialMatches.length === 1) {
    return { type: 'unique', item: partialMatches[0] };
  }
  
  return { type: 'multiple', matches: partialMatches };
}
