
import { type User, type InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";
import { promises as fs } from 'fs';
import path from 'path';

// Interfaces para el bot de Discord
interface GachaItem {
  name: string;
  chance: number;
  rarity: string;
  reply: string;
  giveTokens?: boolean;
  roleGiven?: string;
  objectType?: string;
  promo?: boolean;
  secret?: boolean;
  collectable?: number;
}

interface UserCollectables {
  [itemName: string]: number;
}

interface UserPity {
  counter: number;
  guaranteedPromo: boolean;
}

interface ExchangeRule {
  id: string;
  rewardName: string;
  prices: { [key: string]: number };
  roleGiven?: string;
}

interface GuildData {
  items: GachaItem[];
  config: { [key: string]: any };
  userTokens: { [userId: string]: { [tokenType: string]: number } };
  userPity: { [userId: string]: UserPity };
  exchanges: ExchangeRule[];
  userCollectables: { [userId: string]: UserCollectables };
}

// Storage interface original
export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const GUILDS_FILE = path.join(DATA_DIR, 'guilds.json');

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private guildsData: Map<string, GuildData>;

  constructor() {
    this.users = new Map();
    this.guildsData = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Discord Bot Functions
  private async getGuildData(guildId: string): Promise<GuildData> {
    if (this.guildsData.has(guildId)) {
      return this.guildsData.get(guildId)!;
    }

    // Intentar cargar desde archivo
    try {
      await fs.mkdir(DATA_DIR, { recursive: true });
      const data = await fs.readFile(GUILDS_FILE, 'utf-8');
      const allGuilds = JSON.parse(data);
      
      // Cargar todos los guilds en memoria
      Object.entries(allGuilds).forEach(([id, guildData]) => {
        this.guildsData.set(id, guildData as GuildData);
      });

      if (this.guildsData.has(guildId)) {
        return this.guildsData.get(guildId)!;
      }
    } catch (error) {
      // Archivo no existe o está corrupto, crear nuevo
    }

    const newData: GuildData = {
      items: [],
      config: {},
      userTokens: {},
      userPity: {},
      exchanges: [],
      userCollectables: {}
    };
    this.guildsData.set(guildId, newData);
    await this.saveAllGuilds();
    return newData;
  }

  private async saveAllGuilds(): Promise<void> {
    try {
      await fs.mkdir(DATA_DIR, { recursive: true });
      const allGuilds: { [key: string]: GuildData } = {};
      
      this.guildsData.forEach((data, guildId) => {
        allGuilds[guildId] = data;
      });

      await fs.writeFile(GUILDS_FILE, JSON.stringify(allGuilds, null, 2));
    } catch (error) {
      console.error('Error saving guilds data:', error);
    }
  }

  async ensureDataFiles(): Promise<void> {
    await fs.mkdir(DATA_DIR, { recursive: true });
    console.log('📦 JSON storage initialized at:', DATA_DIR);
  }

  // Config functions
  async getConfig(guildId: string, key: string): Promise<any> {
    const guildData = await this.getGuildData(guildId);
    return guildData.config[key];
  }

  async setConfig(guildId: string, key: string, value: any): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    guildData.config[key] = value;
    await this.saveAllGuilds();
  }

  // Item functions
  async getAllItems(guildId: string): Promise<GachaItem[]> {
    const guildData = await this.getGuildData(guildId);
    return [...guildData.items];
  }

  async createItem(guildId: string, name: string, chance: number, rarity: string, reply: string, secret: boolean = false): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    guildData.items.push({
      name,
      chance,
      rarity,
      reply,
      secret
    });
    await this.saveAllGuilds();
  }

  async getItemByName(guildId: string, name: string): Promise<GachaItem | undefined> {
    const guildData = await this.getGuildData(guildId);
    return guildData.items.find(item => item.name.toLowerCase() === name.toLowerCase());
  }

  async updateItem(guildId: string, itemName: string, field: string, value: any): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    const item = guildData.items.find(i => i.name.toLowerCase() === itemName.toLowerCase());
    if (item) {
      (item as any)[field] = value;
      await this.saveAllGuilds();
    }
  }

  async deleteItem(guildId: string, itemName: string): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    guildData.items = guildData.items.filter(i => i.name.toLowerCase() !== itemName.toLowerCase());
    await this.saveAllGuilds();
  }

  async resetAllItems(guildId: string): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    guildData.items = [];
    guildData.userPity = {};
    await this.saveAllGuilds();
  }

  // Pity system
  async getUserPity(guildId: string, userId: string): Promise<UserPity> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userPity[userId]) {
      guildData.userPity[userId] = { counter: 0, guaranteedPromo: false };
      await this.saveAllGuilds();
    }
    return guildData.userPity[userId];
  }

  async incrementPity(guildId: string, userId: string): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userPity[userId]) {
      guildData.userPity[userId] = { counter: 0, guaranteedPromo: false };
    }
    guildData.userPity[userId].counter++;
    await this.saveAllGuilds();
  }

  async resetPity(guildId: string, userId: string, setGuaranteed: boolean = false): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userPity[userId]) {
      guildData.userPity[userId] = { counter: 0, guaranteedPromo: false };
    }
    guildData.userPity[userId].counter = 0;
    guildData.userPity[userId].guaranteedPromo = setGuaranteed;
    await this.saveAllGuilds();
  }

  async getRandomItemWithPity(guildId: string, userId: string): Promise<GachaItem | null> {
    const guildData = await this.getGuildData(guildId);
    const items = guildData.items;
    
    if (items.length === 0) return null;

    const pity = await this.getUserPity(guildId, userId);
    
    if (pity.counter >= 90) {
      const ssrItems = items.filter(i => i.rarity.toUpperCase() === 'SSR');
      if (ssrItems.length > 0) {
        let selectedItem: GachaItem;
        
        if (pity.guaranteedPromo) {
          const promoSSRs = ssrItems.filter(i => i.promo);
          if (promoSSRs.length > 0) {
            selectedItem = promoSSRs[Math.floor(Math.random() * promoSSRs.length)];
          } else {
            selectedItem = ssrItems[Math.floor(Math.random() * ssrItems.length)];
          }
          await this.resetPity(guildId, userId, false);
        } else {
          selectedItem = ssrItems[Math.floor(Math.random() * ssrItems.length)];
          const isPromo = selectedItem.promo || false;
          await this.resetPity(guildId, userId, !isPromo);
        }
        
        return selectedItem;
      }
    }

    const totalChance = items.reduce((sum, item) => sum + item.chance, 0);
    let random = Math.random() * totalChance;

    for (const item of items) {
      random -= item.chance;
      if (random <= 0) {
        if (item.rarity.toUpperCase() === 'SSR') {
          if (pity.guaranteedPromo && !item.promo) {
            await this.resetPity(guildId, userId, true);
          } else {
            const isPromo = item.promo || false;
            await this.resetPity(guildId, userId, !isPromo);
          }
        } else {
          await this.incrementPity(guildId, userId);
        }
        
        return item;
      }
    }

    return items[items.length - 1] || null;
  }

  // Token functions
  async getUserTokens(guildId: string, userId: string): Promise<{ [tokenType: string]: number }> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userTokens[userId]) {
      guildData.userTokens[userId] = {};
      await this.saveAllGuilds();
    }
    return guildData.userTokens[userId];
  }

  async addTokens(guildId: string, userId: string, tokenType: string, amount: number): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userTokens[userId]) {
      guildData.userTokens[userId] = {};
    }
    guildData.userTokens[userId][tokenType] = (guildData.userTokens[userId][tokenType] || 0) + amount;
    await this.saveAllGuilds();
  }

  async removeTokens(guildId: string, userId: string, tokenType: string, amount: number): Promise<boolean> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userTokens[userId]) {
      guildData.userTokens[userId] = {};
    }
    if ((guildData.userTokens[userId][tokenType] || 0) < amount) {
      return false;
    }
    guildData.userTokens[userId][tokenType] -= amount;
    await this.saveAllGuilds();
    return true;
  }

  async resetAllTokens(guildId: string): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    guildData.userTokens = {};
    await this.saveAllGuilds();
  }

  // Exchange functions
  async createExchange(guildId: string, rewardName: string): Promise<string> {
    const guildData = await this.getGuildData(guildId);
    const id = (guildData.exchanges.length + 1).toString();
    guildData.exchanges.push({
      id,
      rewardName,
      prices: {}
    });
    await this.saveAllGuilds();
    return id;
  }

  async getExchangeRules(guildId: string): Promise<ExchangeRule[]> {
    const guildData = await this.getGuildData(guildId);
    return [...guildData.exchanges];
  }

  async getExchangeById(exchangeId: string): Promise<ExchangeRule | undefined> {
    for (const [guildId, guildData] of this.guildsData) {
      const exchange = guildData.exchanges.find(e => e.id === exchangeId);
      if (exchange) return exchange;
    }
    return undefined;
  }

  async updateExchangePrices(exchangeId: string, prices: { [key: string]: number }): Promise<void> {
    for (const [guildId, guildData] of this.guildsData) {
      const exchange = guildData.exchanges.find(e => e.id === exchangeId);
      if (exchange) {
        exchange.prices = prices;
        await this.saveAllGuilds();
        return;
      }
    }
  }

  async updateExchangeRole(exchangeId: string, role: string | null): Promise<void> {
    for (const [guildId, guildData] of this.guildsData) {
      const exchange = guildData.exchanges.find(e => e.id === exchangeId);
      if (exchange) {
        if (role === null) {
          delete exchange.roleGiven;
        } else {
          exchange.roleGiven = role;
        }
        await this.saveAllGuilds();
        return;
      }
    }
  }

  async resetAllExchanges(guildId: string): Promise<number> {
    const guildData = await this.getGuildData(guildId);
    const count = guildData.exchanges.length;
    guildData.exchanges = [];
    await this.saveAllGuilds();
    return count;
  }

  // Collectable functions
  async getUserCollectables(guildId: string, userId: string): Promise<UserCollectables> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userCollectables) {
      guildData.userCollectables = {};
    }
    if (!guildData.userCollectables[userId]) {
      guildData.userCollectables[userId] = {};
      await this.saveAllGuilds();
    }
    return guildData.userCollectables[userId];
  }

  async addCollectable(guildId: string, userId: string, itemName: string): Promise<number> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userCollectables) {
      guildData.userCollectables = {};
    }
    if (!guildData.userCollectables[userId]) {
      guildData.userCollectables[userId] = {};
    }
    guildData.userCollectables[userId][itemName] = (guildData.userCollectables[userId][itemName] || 0) + 1;
    await this.saveAllGuilds();
    return guildData.userCollectables[userId][itemName];
  }

  async getCollectableCount(guildId: string, userId: string, itemName: string): Promise<number> {
    const collectables = await this.getUserCollectables(guildId, userId);
    return collectables[itemName] || 0;
  }

  async resetCollectable(guildId: string, userId: string, itemName: string): Promise<void> {
    const guildData = await this.getGuildData(guildId);
    if (!guildData.userCollectables) {
      guildData.userCollectables = {};
    }
    if (!guildData.userCollectables[userId]) {
      guildData.userCollectables[userId] = {};
    }
    delete guildData.userCollectables[userId][itemName];
    await this.saveAllGuilds();
  }
}

// Utility functions
export function getRarityColor(rarity: string): number {
  const rarityColors: { [key: string]: number } = {
    'SSR': 0xFFD700,
    'SR': 0xA020F0,
    'UR': 0x3498DB,
    'R': 0x2ECC71
  };
  return rarityColors[rarity.toUpperCase()] || 0x808080;
}

export function RarityColor(rarity: string): number {
  return getRarityColor(rarity);
}

export function getRarityStars(rarity: string): string {
  const rarityStars: { [key: string]: string } = {
    'SSR': '<:RStarR:1425259849477918837><:RStar:1425259703981703208><:RStarR:1425259849477918837><:RStar:1425259703981703208><:RStarR:1425259849477918837>',
    'SR': '<:RStarR:1425259849477918837><:RStar:1425259703981703208><:RStarR:1425259849477918837><:RStar:1425259703981703208>',
    'UR': '<:RStarR:1425259849477918837><:RStar:1425259703981703208><:RStarR:1425259849477918837>',
    'R': '<:RStarR:1425259849477918837><:RStar:1425259703981703208>'
  };
  return rarityStars[rarity.toUpperCase()] || '★';
}

export async function getTokenEmoji(guildIdOrRarity: string, rarity?: string): Promise<string> {
  const actualRarity = rarity || guildIdOrRarity;
  const emojiMap: { [key: string]: string } = {
    'SSR': '<:SSRTK:1425246335472369857>',
    'SR': '<:SRTK:1425246269307359395>',
    'UR': '<:URTK:1425246198071033906>',
    'R': '<:RTK:1425246396654682272>'
  };
  return emojiMap[actualRarity.toUpperCase()] || '🎫';
}

export async function getRarityTokenEmoji(rarity: string): Promise<string> {
  return getTokenEmoji(rarity);
}

const storageInstance = new MemStorage();
export const storage = storageInstance;

// Export all Discord bot functions as standalone functions
export async function ensureDataFiles(): Promise<void> {
  return storageInstance.ensureDataFiles();
}

export async function getConfig(guildId: string, key: string): Promise<any> {
  return storageInstance.getConfig(guildId, key);
}

export async function setConfig(guildId: string, key: string, value: any): Promise<void> {
  return storageInstance.setConfig(guildId, key, value);
}

export async function getAllItems(guildId: string): Promise<any[]> {
  return storageInstance.getAllItems(guildId);
}

export async function createItem(guildId: string, name: string, chance: number, rarity: string, reply: string, secret: boolean = false): Promise<void> {
  return storageInstance.createItem(guildId, name, chance, rarity, reply, secret);
}

export async function getItemByName(guildId: string, name: string): Promise<any> {
  return storageInstance.getItemByName(guildId, name);
}

export async function updateItem(guildId: string, itemName: string, field: string, value: any): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, field, value);
}

export async function deleteItem(guildId: string, itemName: string): Promise<void> {
  return storageInstance.deleteItem(guildId, itemName);
}

export async function resetAllItems(guildId: string): Promise<void> {
  return storageInstance.resetAllItems(guildId);
}

export async function getUserPity(guildId: string, userId: string): Promise<any> {
  return storageInstance.getUserPity(guildId, userId);
}

export async function getRandomItemWithPity(guildId: string, userId: string): Promise<any> {
  return storageInstance.getRandomItemWithPity(guildId, userId);
}

export async function getUserTokens(guildId: string, userId: string): Promise<{ [tokenType: string]: number }> {
  return storageInstance.getUserTokens(guildId, userId);
}

export async function addTokens(guildId: string, userId: string, tokenType: string, amount: number): Promise<void> {
  return storageInstance.addTokens(guildId, userId, tokenType, amount);
}

export async function removeTokens(guildId: string, userId: string, tokenType: string, amount: number): Promise<boolean> {
  return storageInstance.removeTokens(guildId, userId, tokenType, amount);
}

export async function resetAllTokens(guildId: string): Promise<void> {
  return storageInstance.resetAllTokens(guildId);
}

export async function createExchange(guildId: string, rewardName: string): Promise<string> {
  return storageInstance.createExchange(guildId, rewardName);
}

export async function getExchangeRules(guildId: string): Promise<any[]> {
  return storageInstance.getExchangeRules(guildId);
}

export async function getExchangeById(exchangeId: string): Promise<any> {
  return storageInstance.getExchangeById(exchangeId);
}

export async function updateExchangePrices(exchangeId: string, prices: { [key: string]: number }): Promise<void> {
  return storageInstance.updateExchangePrices(exchangeId, prices);
}

export async function updateExchangeRole(exchangeId: string, role: string | null): Promise<void> {
  return storageInstance.updateExchangeRole(exchangeId, role);
}

export async function resetAllExchanges(guildId: string): Promise<number> {
  return storageInstance.resetAllExchanges(guildId);
}

export async function updateItemReply(guildId: string, itemName: string, reply: string): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'reply', reply);
}

export async function updateItemChance(guildId: string, itemName: string, chance: number): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'chance', chance);
}

export async function updateItemRarity(guildId: string, itemName: string, rarity: string): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'rarity', rarity);
}

export async function updateItemTokens(guildId: string, itemName: string, giveTokens: boolean): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'giveTokens', giveTokens);
}

export async function updateItemRoleGiven(guildId: string, itemName: string, roleGiven: string | null): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'roleGiven', roleGiven);
}

export async function updateItemObjectType(guildId: string, itemName: string, objectType: string): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'objectType', objectType);
}

export async function updateItemPromo(guildId: string, itemName: string, promo: boolean): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'promo', promo);
}

export async function updateItemCollectable(guildId: string, itemName: string, collectable: number | null): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'collectable', collectable);
}

export async function updateItemSecret(guildId: string, itemName: string, secret: boolean): Promise<void> {
  return storageInstance.updateItem(guildId, itemName, 'secret', secret);
}

export async function getUserCollectables(guildId: string, userId: string): Promise<any> {
  return storageInstance.getUserCollectables(guildId, userId);
}

export async function addCollectable(guildId: string, userId: string, itemName: string): Promise<number> {
  return storageInstance.addCollectable(guildId, userId, itemName);
}

export async function getCollectableCount(guildId: string, userId: string, itemName: string): Promise<number> {
  return storageInstance.getCollectableCount(guildId, userId, itemName);
}

export async function resetCollectable(guildId: string, userId: string, itemName: string): Promise<void> {
  return storageInstance.resetCollectable(guildId, userId, itemName);
}
