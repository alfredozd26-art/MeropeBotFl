# 🚀 Cómo Ejecutar tu Bot de Discord

## ✅ Tu bot está listo y configurado

Todas las dependencias están instaladas y el código está funcionando correctamente.

## 📋 Pasos para ejecutar el bot:

### Opción 1: Ejecutar manualmente desde la terminal

1. Abre la **Shell** (terminal) de Replit
2. Ejecuta este comando:
   ```bash
   tsx index.ts
   ```
3. Verás el mensaje: **"✅ Bot conectado como Merope#9713"**

### Opción 2: Crear un workflow personalizado (Recomendado para 24/7)

1. Ve al panel **"Workflows"** en Replit (icono de engranaje ⚙️)
2. Haz clic en **"Create Workflow"**
3. Dale un nombre como: **"Discord Bot"**
4. Añade un paso de tipo **"Execute Shell Command"**
5. En el comando escribe: `tsx index.ts`
6. Guarda el workflow
7. Asigna el workflow al botón **"Run"**
8. ¡Presiona Run y tu bot estará activo 24/7!

## 🔑 Verificar Token de Discord

Tu token de Discord ya está configurado como secreto `DISCORD_TOKEN`. Si necesitas cambiarlo:

1. Ve a **Secrets** (icono de llave 🔑) en el panel izquierdo
2. Busca `DISCORD_TOKEN`
3. Actualiza el valor si es necesario

## 🎯 ¿Cómo sé que funciona?

Cuando el bot se ejecuta correctamente verás estos mensajes en la consola:

```
[dotenv@17.2.3] injecting env...
🌐 Servidor web corriendo en puerto 3000
✅ Bot conectado como Merope#9713
📦 In-memory storage initialized
```

## 📝 Siguiente paso: Configurar tu servidor de Discord

Una vez que el bot esté corriendo, ve a tu servidor de Discord y:

1. **Configura los roles de tickets:**
   ```
   *setticketrole @Ticket
   *setticketrole10 @Ticket x10
   ```

2. **Crea tu primer item/premio:**
   ```
   *createitem Joker Premium
   *edititem Joker Premium rarity SSR
   *edititem Joker Premium chance 10
   *edititem Joker Premium reply https://url-de-tu-imagen.gif
   *edititem Joker Premium tokens si
   *edititem Joker Premium role-given @Joker
   ```

3. **Prueba el banner:**
   ```
   *banner
   ```

## ⚙️ Configuración Actual

- ✅ **Discord.js**: Instalado
- ✅ **Dotenv**: Instalado
- ✅ **Storage en memoria**: Configurado
- ✅ **Token de Discord**: Configurado como secreto
- ✅ **Sistema Gacha**: Funcional
- ✅ **Sistema Pity**: Funcional
- ✅ **Sistema de Tokens**: Funcional
- ✅ **Servidor web (puerto 3000)**: Para mantener el bot activo

## 🐛 Si algo no funciona

1. Verifica que el token de Discord sea correcto
2. Asegúrate de que el bot tenga permisos en tu servidor de Discord
3. Revisa la consola para ver mensajes de error
4. El rol del bot debe estar por encima de los roles que asigna

## 📚 Documentación Completa

Lee el archivo **`BOT_DOCUMENTACION.md`** para ver todos los comandos disponibles y cómo usar cada función del bot.

---

¡Tu bot está listo para usar! 🎉
