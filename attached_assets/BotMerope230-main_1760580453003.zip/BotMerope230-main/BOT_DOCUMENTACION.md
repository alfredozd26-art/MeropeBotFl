# 🎰 Bot de Discord Gacha - Documentación

## ✅ Estado del Bot
Tu bot está **funcionando correctamente** y conectado a Discord como **Merope#9713**

## 🎮 ¿Qué hace tu bot?

Es un bot de Discord tipo gacha con sistema de tickets, rareza, pity system y tokens para duplicados. Los usuarios pueden hacer "tiradas" (pulls) para obtener premios/personajes usando tickets.

## 📋 Comandos Principales

### 🎰 Comandos de Juego
- **`*girar`** - Hacer un giro del gacha (requiere Ticket)
- **`*girar10`** - Hacer 10 giros del gacha (requiere Ticket x10)
- **`*banner`** - Ver el banner actual con probabilidades
- **`*pity`** - Ver tu contador de pity actual

### 💎 Comandos de Tokens
- **`*tokens`** o **`*bal`** - Ver tus Tokens acumulados
- **`*canjear <ID>`** - Canjear Tokens por recompensas
- **`*listexchanges`** - Ver canjes disponibles

### ⚙️ Comandos de Administración (Solo Admins)

#### Gestión de Items/Premios
- **`*createitem <nombre>`** - Crear un nuevo premio
  - Ejemplo: `*createitem Joker Premium`
  
- **`*createitemsecret <nombre>`** - Crear personaje secreto 🔒
  - Ejemplo: `*createitemsecret Johnny`
  - *No aparece en el banner público*

- **`*edititem <nombre> <campo> <valor>`** - Editar premio
  - Campos: `chance`, `rarity`, `reply`, `tokens`, `role-given`, `object`, `promo`
  - Ejemplos:
    - `*edititem Joker rarity SSR`
    - `*edititem Joker chance 5`
    - `*edititem Joker reply https://imagen.gif`
    - `*edititem Joker tokens si`
    - `*edititem Joker role-given @NombreRol`
    - `*edititem Joker promo true`

- **`*deleteitem <nombre>`** - Eliminar un premio (requiere confirmación)
- **`*resetitems`** - Eliminar todos los premios (requiere confirmación)
- **`*iteminfo <nombre>`** - Ver información de un premio
- **`*secretbanner`** - Ver solo personajes secretos (admin) 🔒

#### Gestión de Tokens
- **`*addtokens <@usuario> <cantidad><rareza>`** - Dar tokens a un usuario
  - Ejemplo: `*addtokens @Juan 5SSR`
  
- **`*removetokens <@usuario> <cantidad><rareza>`** - Quitar tokens
  - Ejemplo: `*removetokens @Juan 2SR`
  
- **`*resettokens`** - Resetear tokens de todos (requiere confirmación)

#### Gestión de Canjes
- **`*createexchange <nombre>`** - Crear un nuevo canje
  - Ejemplo: `*createexchange Spin Gratis`
  
- **`*editexchange <id> price <tokens>`** - Editar precios del canje
  - Ejemplo: `*editexchange 1 price 1SSR 3SR 10UR 40R`
  
- **`*editexchange <id> role <rol>`** - Asignar rol al canje
  - Ejemplo: `*editexchange 1 role @Ticket`
  
- **`*resetexchanges`** - Eliminar todos los canjes

#### Configuración del Bot
- **`*setticketrole <rol>`** - Configurar rol de ticket para `*girar`
- **`*setticketrole10 <rol>`** - Configurar rol de ticket para `*girar10`
- **`*editpull <url_gif>`** - Configurar GIF de tirada normal
- **`*editpull remove`** - Quitar GIF de tirada normal
- **`*editpullssr <url_gif>`** - Configurar GIF para SSR/Promocional
- **`*editpullssr remove`** - Quitar GIF de SSR/Promocional
- **`*setcurrency <emoji>`** - Configurar emoji del título de tokens

### ℹ️ Ayuda
- **`*fixhelp`** - Mostrar menú de ayuda completo

## ⭐ Sistema de Rarezas

- **SSR** <:SSRTK:1425246335472369857> - Super Super Raro (5★)
- **SR** <:SRTK:1425246269307359395> - Super Raro (4★)
- **UR** <:URTK:1425246198071033906> - Ultra Raro (3★)
- **R** <:RTK:1425246396654682272> - Raro (2★)

### ⭐ Símbolo de Promocional
Los items marcados con ⭐ son personajes promocionales del banner actual.

## 🎯 Sistema Pity

El bot tiene un sistema de pity similar a Genshin Impact:
- Cada 90 tiradas sin SSR, la siguiente tirada garantiza un SSR
- Sistema 50/50: Si sacas un SSR estándar, el próximo SSR será promocional garantizado
- El contador de pity se reinicia al obtener un SSR

## 💫 Sistema de Tokens

Cuando obtienes un premio duplicado (un personaje/item que ya tienes), recibes Tokens en su lugar:
- Los tokens se acumulan por rareza (Token SSR, Token SR, Token UR, Token R)
- Puedes canjear tokens por premios específicos usando `*canjear <ID>`
- Los administradores pueden crear canjes personalizados

## 🔒 Personajes Secretos

Los personajes secretos:
- No aparecen en el banner público (`*banner`)
- Solo los administradores pueden verlos con `*secretbanner`
- Se pueden obtener en tiradas normales pero son sorpresas
- Se crean con `*createitemsecret <nombre>`

## 🎫 Sistema de Tickets

- Los usuarios necesitan tener el rol "Ticket" (configurable) para hacer tiradas
- El rol se consume automáticamente después de cada tirada
- Para 10 tiradas se necesita el rol "Ticket x10" (configurable)
- Los usuarios compran tickets en otro bot (Neko, ID: <@292953664492929025>)

## 🔧 Configuración Inicial (Admins)

1. **Configurar roles de tickets:**
   ```
   *setticketrole @Ticket
   *setticketrole10 @Ticket x10
   ```

2. **Crear items/premios:**
   ```
   *createitem Joker Premium
   *edititem Joker Premium rarity SSR
   *edititem Joker Premium chance 1
   *edititem Joker Premium reply https://url-imagen.gif
   *edititem Joker Premium tokens si
   *edititem Joker Premium role-given @Joker
   ```

3. **Configurar GIFs de tirada (opcional):**
   ```
   *editpull https://url-gif-normal.gif
   *editpullssr https://url-gif-ssr.gif
   ```

4. **Crear canjes de tokens:**
   ```
   *createexchange Ticket Gratis
   *editexchange 1 price 5SSR 10SR
   *editexchange 1 role @Ticket
   ```

## 📝 Notas Importantes

- El bot usa almacenamiento en memoria, así que los datos se pierden si el bot se reinicia
- Asegúrate de que el bot tenga permisos para gestionar roles
- El rol del bot debe estar por encima de los roles que asigna
- Usa `*confirmar` y `*cancelar` para acciones destructivas

## 🚀 Cómo Mantener el Bot Activo

El bot tiene un servidor web en el puerto 3000 para servicios como UptimeRobot. Esto ayuda a mantener el bot activo 24/7.

## 🐛 Resolución de Problemas

**El bot no quita el ticket:**
- Verifica que el rol del bot esté por encima del rol de ticket en la jerarquía del servidor

**Los usuarios no reciben roles:**
- Asegúrate de que el rol del bot esté por encima del rol que intenta asignar

**No aparecen items en el banner:**
- Verifica que hayas creado items con `*createitem` y configurado su probabilidad con `*edititem`

---

¡Tu bot está listo para usar! 🎉
