# Discord Gacha Bot

## Overview

This is a Discord bot that implements a gacha (random prize) system with ticket-based pulls, rarity tiers, pity mechanics, and token rewards for duplicates. Users can perform single or 10-pull gacha rolls to obtain prizes/characters with varying rarities. The system includes secret items, promotional items, role assignments, and a token exchange system.

The application consists of:
- A Discord bot (primary functionality) built with Discord.js
- An Express web server (minimal, primarily for health checks)
- A React frontend dashboard (scaffolded with shadcn/ui components but not yet implemented)
- In-memory data storage with planned PostgreSQL migration using Drizzle ORM

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Architecture (Discord.js)

**Command System**
- Prefix-based commands using `*` as the command trigger
- Two categories: User commands (gacha pulls, inventory, exchanges) and Admin commands (item management, token grants)
- Commands are processed through a message listener that parses arguments and routes to handlers
- Confirmation system for destructive operations using a Map-based temporary storage with timeouts

**Gacha Mechanics**
- **Pull System**: Single pulls (`*girar`) and 10-pulls (`*girar10`) consume tickets from user roles
- **Rarity System**: Supports multiple rarity tiers (SSR, SR, R, etc.) with configurable drop rates
- **Pity System**: Tracks failed pulls and guarantees rare items after threshold; includes promotional item guarantees
- **Secret Items**: Items flagged as secret don't appear in public banners but can still be obtained
- **Token System**: Duplicate items award tokens of the same rarity, which can be exchanged for rewards

**Item Management**
- Items have: name, chance (drop rate), rarity, reply (image/GIF URL), token rewards, role assignments, object type, promotional flag, secret flag
- Flexible editing system allowing admins to modify any item property
- Partial name search for item lookup to improve UX

**Data Persistence**
- Currently uses in-memory storage (MemStorage class) with guild-scoped data
- Stores: gacha items, user tokens by rarity, user pity counters, exchange rules, guild configurations
- Data structure supports multi-guild operation with separate state per Discord server

### Backend Architecture (Express)

**Server Setup**
- Express server with JSON body parsing
- Development/production mode detection via NODE_ENV
- Request logging middleware tracking API calls with response times
- Static file serving for React build output in production

**API Design**
- Routes prefixed with `/api` (currently minimal implementation)
- Storage interface abstraction allowing future database migration
- Health check endpoint via root web server

### Frontend Architecture (React + Vite)

**Stack**
- React 18 with TypeScript
- Vite for build tooling and dev server
- Wouter for client-side routing
- TanStack Query for server state management
- shadcn/ui component library (Radix UI primitives + Tailwind CSS)

**Design System**
- Dark-mode-first gaming aesthetic inspired by Discord and gacha games
- Custom color palette with Discord blurple primary, gacha purple accent, and rarity-specific colors (green for rare, purple for epic, gold for legendary)
- Typography: Inter/DM Sans for body, Poppins/Montserrat for headers, JetBrains Mono for code/stats
- Responsive grid layouts with Tailwind breakpoints

**State Management**
- React Query for async state with custom query functions
- Centralized API request utility with error handling
- Toast notifications for user feedback

**Component Architecture**
- Comprehensive UI component library from shadcn/ui (40+ components)
- Atomic design pattern with reusable primitives
- Form handling via react-hook-form with Zod validation

### Data Storage

**Current Implementation (In-Memory)**
- MemStorage class implementing IStorage interface
- Guild-based data isolation using Map structures
- No persistence across restarts

**Planned Migration (PostgreSQL + Drizzle ORM)**
- Drizzle ORM configured with PostgreSQL dialect
- Schema defined in `shared/schema.ts` with user table as starting point
- Migration system ready via `drizzle-kit push`
- Database URL configuration via environment variable
- Neon serverless PostgreSQL client for edge compatibility

The storage interface is designed for easy swap from in-memory to database:
```typescript
interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}
```

### Authentication & Authorization

**Discord Bot Permissions**
- Requires role management permissions to assign roles based on gacha pulls
- Admin commands check for administrator permissions via Discord.js PermissionFlagsBits
- Uses Discord Gateway intents: Guilds, GuildMessages, MessageContent, GuildMembers

**Web Dashboard** (Planned)
- No authentication currently implemented
- Future: Discord OAuth2 integration for dashboard access
- Session management scaffolded with connect-pg-simple for PostgreSQL session storage

## External Dependencies

### Third-Party Services

**Discord API**
- Discord.js v14 for bot functionality
- Gateway connection for real-time message events
- Required environment variable: `DISCORD_TOKEN`
- Bot requires specific intents: Guilds, Messages, Message Content, Members

### Database

**PostgreSQL (Planned)**
- Neon serverless PostgreSQL via `@neondatabase/serverless`
- Connection via DATABASE_URL environment variable
- Drizzle ORM for type-safe database queries and migrations
- Connection pooling and edge compatibility built-in

### UI Framework & Components

**Core Libraries**
- React 18 with TypeScript
- Radix UI primitives for accessible components
- Tailwind CSS for styling with custom design tokens
- Vite for build tooling with hot module replacement

**Component Dependencies**
- Form management: react-hook-form with @hookform/resolvers for Zod integration
- Data visualization: Recharts for charts
- Date utilities: date-fns
- Command palette: cmdk
- Carousel: embla-carousel-react
- Day picker: react-day-picker
- Drawer: vaul

### Development Tools

**Replit Integration**
- Custom Vite plugins for Replit environment:
  - `@replit/vite-plugin-runtime-error-modal` for error overlays
  - `@replit/vite-plugin-cartographer` for code mapping
  - `@replit/vite-plugin-dev-banner` for dev mode indication

**Build & Runtime**
- tsx for TypeScript execution
- esbuild for server bundling
- dotenv for environment variable management
- TypeScript with strict mode enabled

### Configuration Files

- `drizzle.config.ts`: Database migrations and schema configuration
- `components.json`: shadcn/ui component configuration with "new-york" style
- `tailwind.config.ts`: Extended design system with custom colors and CSS variables
- `vite.config.ts`: Frontend build configuration with path aliases
- `tsconfig.json`: TypeScript compilation with ESNext modules and path mapping